# Ideas de Diseño - Landing Page Fibra Óptica Colombia

## Idea 1: Minimalismo Corporativo Moderno (Probabilidad: 0.08)

**Movimiento de Diseño:** Minimalismo corporativo con toques de neomorfismo suave

**Principios Centrales:**
- Claridad radical: máxima legibilidad, jerarquía visual extrema
- Funcionalidad pura: cada elemento tiene propósito comercial
- Confianza a través de la sencillez: menos elementos = más profesionalismo
- Velocidad visual: información crítica en la primera línea de visión

**Filosofía de Color:**
- Paleta primaria: Azul profundo (#0F3A7D) + Blanco puro (#FFFFFF)
- Acentos: Naranja energético (#FF6B35) para CTAs
- Fondos: Blanco con sutiles gradientes lineales grises
- Intención emocional: confianza, seguridad, modernidad

**Paradigma de Layout:**
- Grid asimétrico de 3 columnas en desktop
- Secciones con márgenes amplios y aire negativo
- Alternancia de contenido: imagen derecha → texto izquierda
- Bloques de color sólido para diferenciación de secciones

**Elementos Distintivos:**
1. Líneas geométricas diagonales sutiles como divisores
2. Tarjetas con sombra mínima (0.5px blur) y bordes redondeados de 8px
3. Tipografía con peso variable: títulos en 700, cuerpo en 400

**Filosofía de Interacción:**
- Hover: cambio de color suave (200ms) sin escala
- Botones: fondo sólido con transición de opacidad
- Scroll: revelación progresiva de elementos con fade-in suave

**Animación:**
- Fade-in en scroll: 400ms ease-out
- Hover en tarjetas: cambio de sombra (0.5px → 2px) en 150ms
- CTAs: pulse suave en 200ms al pasar el mouse
- Respeto a `prefers-reduced-motion`

**Sistema Tipográfico:**
- Display: Poppins Bold (700) para títulos principales
- Heading: Poppins SemiBold (600) para subtítulos
- Body: Inter Regular (400) para párrafos
- Jerarquía: 48px → 32px → 24px → 16px → 14px

---

## Idea 2: Energía Dinámica con Gradientes (Probabilidad: 0.07)

**Movimiento de Diseño:** Diseño de energía cinética con gradientes direccionales

**Principios Centrales:**
- Movimiento visual constante: gradientes que guían la vista
- Contraste dinámico: colores complementarios en tensión
- Modernidad agresiva: formas angulares y líneas diagonales
- Velocidad percibida: elementos que sugieren movimiento

**Filosofía de Color:**
- Gradiente primario: Azul cian (#00D9FF) → Azul profundo (#0052CC)
- Gradiente secundario: Naranja (#FF6B35) → Rojo coral (#FF3D00)
- Fondos: Gradientes direccionales a 45° en cada sección
- Intención emocional: innovación, velocidad, futuro

**Paradigma de Layout:**
- Secciones con clip-path diagonales (polígonos angulares)
- Contenido fluye en diagonal: arriba-izquierda a abajo-derecha
- Superposición de elementos con z-index estratégico
- Márgenes negativos para crear tensión visual

**Elementos Distintivos:**
1. Formas geométricas angulares como separadores
2. Tarjetas con bordes redondeados asimétricos (12px arriba, 4px abajo)
3. Líneas de acento en gradiente que cruzan elementos

**Filosofía de Interacción:**
- Hover: rotación sutil (2°) + escala (1.02) en 200ms
- Botones: fondo en gradiente que se anima en hover
- Scroll: elementos que rotan y cambian gradiente

**Animación:**
- Entrada: scale(0.95) + opacity(0) → scale(1) + opacity(1) en 500ms
- Hover: rotación 2° + escala 1.02 en 200ms
- Scroll: elementos que cambian gradiente progresivamente
- Stagger: 50ms entre elementos de lista

**Sistema Tipográfico:**
- Display: Clash Display Bold (700) para impacto máximo
- Heading: Clash Display Medium (500) para subtítulos
- Body: Inter Regular (400) para legibilidad
- Jerarquía: 56px → 40px → 28px → 18px → 14px

---

## Idea 3: Elegancia Premium Oscura (Probabilidad: 0.06)

**Movimiento de Diseño:** Lujo digital con tema oscuro y detalles dorados

**Principios Centrales:**
- Sofisticación a través de la oscuridad: fondo oscuro = premium
- Minimalismo lujoso: menos elementos, más refinamiento
- Contraste dramático: texto claro sobre fondos oscuros
- Exclusividad percibida: paleta limitada y controlada

**Filosofía de Color:**
- Fondos: Gris oscuro profundo (#0A0E27) → Negro puro (#000000)
- Acentos primarios: Dorado (#D4AF37) para detalles y CTAs
- Acentos secundarios: Azul plateado (#E8F4F8) para información
- Intención emocional: lujo, confianza, exclusividad

**Paradigma de Layout:**
- Secciones amplias con mucho aire negativo
- Contenido centrado con máx-ancho de 1000px
- Bordes sutiles en dorado para enmarcar secciones
- Tipografía grande y espaciada

**Elementos Distintivos:**
1. Líneas decorativas en dorado que enmarcan secciones
2. Tarjetas con borde dorado sutil (1px) y fondo con gradiente oscuro
3. Iconografía minimalista en dorado

**Filosofía de Interacción:**
- Hover: brillo suave (glow) en dorado en 250ms
- Botones: borde dorado que se llena de color en hover
- Scroll: elementos que revelan detalles dorados

**Animación:**
- Fade-in en scroll: 600ms ease-out con stagger de 80ms
- Hover en elementos: glow dorado (box-shadow) en 250ms
- CTAs: borde que se anima (stroke-dasharray) en 400ms
- Respeto a `prefers-reduced-motion`

**Sistema Tipográfico:**
- Display: Playfair Display Bold (700) para elegancia
- Heading: Playfair Display SemiBold (600)
- Body: Lato Regular (400) para legibilidad en oscuro
- Jerarquía: 52px → 36px → 26px → 18px → 14px

---

## Decisión Final: **Idea 1 - Minimalismo Corporativo Moderno**

Se selecciona este enfoque porque:
1. **Máxima conversión**: Claridad radical reduce fricción en CTAs
2. **Confianza**: Azul corporativo + blanco transmiten profesionalismo
3. **Mobile-first**: Sencillez es más responsive
4. **SEO**: Estructura clara mejora rastreo de buscadores
5. **Ads**: Minimalismo funciona mejor en Facebook/Google Ads
6. **Performance**: Menos animaciones = mejor Core Web Vitals

import { MessageCircle } from "lucide-react";
import { COMPANY_INFO } from "@/data/content";

export function WhatsAppButton() {
  const whatsappUrl = `https://wa.me/${COMPANY_INFO.whatsapp.replace(/\D/g, "")}?text=Hola, me gustaría obtener más información sobre los planes de internet fibra óptica.`;

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 flex items-center justify-center w-14 h-14 rounded-full bg-green-500 hover:bg-green-600 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110 group"
      title="Contactar por WhatsApp"
    >
      <MessageCircle className="h-6 w-6 group-hover:scale-110 transition-transform" />
      
      {/* Tooltip */}
      <div className="absolute right-full mr-4 px-3 py-2 bg-foreground text-background rounded-lg text-sm font-semibold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
        Contactar por WhatsApp
      </div>
    </a>
  );
}

export default WhatsAppButton;

import { BENEFITS } from "@/data/content";
import {
  Zap,
  Shield,
  Clock,
  Wifi,
  Users,
  TrendingUp,
} from "lucide-react";

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Zap,
  Shield,
  Clock,
  Wifi,
  Users,
  TrendingUp,
};

export function Benefits() {
  return (
    <section className="py-20 md:py-32 bg-background">
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold font-bold text-foreground">
            Beneficios de la Fibra Óptica
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Experimenta la diferencia con tecnología de fibra óptica de última generación
          </p>
        </div>

        {/* Grid de beneficios */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {BENEFITS.map((benefit, index) => {
            const Icon = iconMap[benefit.icon];
            return (
              <div
                key={index}
                className="group p-8 rounded-lg bg-card border border-border hover:border-primary/50 hover:shadow-lg transition-all duration-300 hover:translate-y-[-4px]"
              >
                {/* Icono */}
                <div className="mb-6 inline-flex p-3 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
                  {Icon && (
                    <Icon className="h-6 w-6 text-primary" />
                  )}
                </div>

                {/* Título */}
                <h3 className="text-xl font-bold text-foreground mb-3">
                  {benefit.title}
                </h3>

                {/* Descripción */}
                <p className="text-muted-foreground leading-relaxed">
                  {benefit.description}
                </p>

                {/* Línea decorativa */}
                <div className="mt-6 h-1 w-12 bg-accent rounded-full group-hover:w-full transition-all duration-300" />
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export default Benefits;

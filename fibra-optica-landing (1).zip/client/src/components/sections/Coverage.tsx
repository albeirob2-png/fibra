import { COVERAGE_REGIONS } from "@/data/content";
import { MapPin } from "lucide-react";

export function Coverage() {
  return (
    <section className="py-20 md:py-32 bg-background">
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold font-bold text-foreground">
            Cobertura en Colombia
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Estamos presentes en las principales ciudades del país
          </p>
        </div>

        {/* Mapa decorativo */}
        <div className="mb-12 rounded-xl overflow-hidden bg-card border border-border">
          <img
            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663619836959/jSrDYwLpzzFeHqksKux63d/coverage-map-9n6fw7FQoJhnLjZdFDoPYq.webp"
            alt="Mapa de cobertura de fibra óptica en Colombia"
            className="w-full h-auto"
          />
        </div>

        {/* Tabla de ciudades */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {COVERAGE_REGIONS.map((region, index) => (
            <div
              key={index}
              className="p-6 rounded-lg bg-card border border-border hover:border-primary/50 transition-colors"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <MapPin className="h-5 w-5 text-accent flex-shrink-0" />
                  <h3 className="text-lg font-bold text-foreground">
                    {region.name}
                  </h3>
                </div>
                <span
                  className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    region.status === "Activa"
                      ? "bg-green-100 text-green-700"
                      : "bg-blue-100 text-blue-700"
                  }`}
                >
                  {region.status}
                </span>
              </div>

              {/* Barra de cobertura */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">
                    Cobertura
                  </span>
                  <span className="text-sm font-semibold text-primary">
                    {region.coverage}
                  </span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-primary to-accent rounded-full transition-all duration-500"
                    style={{
                      width: region.coverage,
                    }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA para verificar cobertura */}
        <div className="mt-12 p-8 rounded-xl bg-gradient-to-r from-primary/10 to-accent/10 border border-primary/20 text-center">
          <h3 className="text-2xl font-bold text-foreground mb-2">
            Verifica tu cobertura
          </h3>
          <p className="text-muted-foreground mb-6">
            Ingresa tu dirección para saber si ya estamos en tu zona
          </p>
          <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input
              type="text"
              placeholder="Tu dirección"
              className="flex-1 px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <button className="px-6 py-3 rounded-lg bg-accent hover:bg-accent/90 text-accent-foreground font-semibold transition-colors">
              Verificar
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Coverage;

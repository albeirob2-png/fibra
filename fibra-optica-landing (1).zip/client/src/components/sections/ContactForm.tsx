import { useState } from "react";
import { Button } from "@/components/ui/button";
import { CONTACT_FORM, COMPANY_INFO, PLANS } from "@/data/content";
import { toast } from "sonner";
import { Send } from "lucide-react";

interface FormData {
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  plan: string;
}

export function ContactForm() {
  const [formData, setFormData] = useState<FormData>({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    plan: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Validar campos requeridos
      if (!formData.name || !formData.email || !formData.phone || !formData.address || !formData.city) {
        toast.error("Por favor completa todos los campos requeridos");
        setIsSubmitting(false);
        return;
      }

      // Crear mensaje para WhatsApp
      const message = `Hola, me gustaría solicitar información sobre los planes de internet fibra óptica.

*Datos del cliente:*
Nombre: ${formData.name}
Email: ${formData.email}
Teléfono: ${formData.phone}
Dirección: ${formData.address}
Ciudad: ${formData.city}
${formData.plan ? `Plan de interés: ${formData.plan}` : ""}

Por favor, confirma disponibilidad en mi zona y envíame más información.`;

      // Redirigir a WhatsApp
      const whatsappUrl = `https://wa.me/${COMPANY_INFO.whatsapp.replace(/\D/g, "")}?text=${encodeURIComponent(message)}`;
      window.open(whatsappUrl, "_blank");

      // Limpiar formulario
      setFormData({
        name: "",
        email: "",
        phone: "",
        address: "",
        city: "",
        plan: "",
      });

      toast.success("Redirigiendo a WhatsApp...");
    } catch (error) {
      toast.error("Error al procesar el formulario");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="py-20 md:py-32 bg-secondary/30">
      <div className="container max-w-3xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold font-bold text-foreground">
            {CONTACT_FORM.title}
          </h2>
          <p className="text-lg text-muted-foreground">
            {CONTACT_FORM.subtitle}
          </p>
        </div>

        {/* Formulario */}
        <form onSubmit={handleSubmit} className="space-y-6 bg-card p-8 rounded-xl border border-border">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Nombre */}
            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">
                Nombre Completo *
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Tu nombre"
                required
                className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all"
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">
                Correo Electrónico *
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="tu@email.com"
                required
                className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all"
              />
            </div>

            {/* Teléfono */}
            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">
                Teléfono *
              </label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder="+57 3XX XXX XXXX"
                required
                className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all"
              />
            </div>

            {/* Ciudad */}
            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">
                Ciudad *
              </label>
              <select
                name="city"
                value={formData.city}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all"
              >
                <option value="">Selecciona tu ciudad</option>
                <option value="Bogotá">Bogotá</option>
                <option value="Medellín">Medellín</option>
                <option value="Cali">Cali</option>
                <option value="Barranquilla">Barranquilla</option>
                <option value="Cartagena">Cartagena</option>
                <option value="Bucaramanga">Bucaramanga</option>
                <option value="Otra">Otra</option>
              </select>
            </div>
          </div>

          {/* Dirección */}
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">
              Dirección *
            </label>
            <input
              type="text"
              name="address"
              value={formData.address}
              onChange={handleChange}
              placeholder="Tu dirección completa"
              required
              className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all"
            />
          </div>

          {/* Plan */}
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">
              Plan de Interés
            </label>
            <select
              name="plan"
              value={formData.plan}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all"
            >
              <option value="">Selecciona un plan</option>
              {PLANS.map((plan) => (
                <option key={plan.name} value={plan.name}>
                  {plan.name} - {plan.speed}
                </option>
              ))}
            </select>
          </div>

          {/* Botón */}
          <Button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-3 rounded-lg transition-all duration-200 group"
          >
            {isSubmitting ? "Enviando..." : "Enviar Solicitud"}
            <Send className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
          </Button>

          {/* Nota */}
          <p className="text-xs text-muted-foreground text-center">
            Al enviar este formulario, serás redirigido a WhatsApp para confirmar tu solicitud
          </p>
        </form>
      </div>
    </section>
  );
}

export default ContactForm;

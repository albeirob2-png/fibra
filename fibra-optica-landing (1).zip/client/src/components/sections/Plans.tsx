import { Button } from "@/components/ui/button";
import { PLANS } from "@/data/content";
import { Check } from "lucide-react";

interface PlansProps {
  onSelectPlan?: (planName: string) => void;
}

export function Plans({ onSelectPlan }: PlansProps) {
  return (
    <section className="py-20 md:py-32 bg-secondary/30">
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold font-bold text-foreground">
            Planes de Internet
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Elige el plan perfecto para tus necesidades
          </p>
        </div>

        {/* Grid de planes */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {PLANS.map((plan, index) => (
            <div
              key={index}
              className={`relative rounded-xl overflow-hidden transition-all duration-300 ${
                plan.highlighted
                  ? "md:scale-105 shadow-2xl border-2 border-accent"
                  : "border border-border hover:border-primary/50 hover:shadow-lg"
              } ${
                plan.highlighted ? "bg-gradient-to-br from-primary/5 to-accent/5" : "bg-card"
              }`}
            >
              {/* Badge destacado */}
              {plan.highlighted && (
                <div className="absolute top-0 right-0 bg-accent text-accent-foreground px-4 py-2 rounded-bl-lg font-semibold text-sm">
                  Más Popular
                </div>
              )}

              {/* Contenido */}
              <div className="p-8 space-y-6">
                {/* Nombre y velocidad */}
                <div>
                  <h3 className="text-2xl font-bold text-foreground mb-2">
                    {plan.name}
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    {plan.description}
                  </p>
                </div>

                {/* Velocidad destacada */}
                <div className="py-4 border-y border-border">
                  <p className="text-4xl font-bold text-primary mb-1">
                    {plan.speed}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Velocidad simétrica
                  </p>
                </div>

                {/* Precio */}
                <div>
                  <p className="text-3xl font-bold text-foreground">
                    ${plan.price.toLocaleString("es-CO")}
                    <span className="text-lg text-muted-foreground font-normal">
                      /{plan.period}
                    </span>
                  </p>
                </div>

                {/* CTA */}
                <Button
                  size="lg"
                  className={`w-full font-semibold rounded-lg transition-all duration-200 ${
                    plan.highlighted
                      ? "bg-accent hover:bg-accent/90 text-accent-foreground"
                      : "bg-primary hover:bg-primary/90 text-primary-foreground"
                  }`}
                  onClick={() => onSelectPlan?.(plan.name)}
                >
                  Contratar Ahora
                </Button>

                {/* Features */}
                <div className="space-y-3 pt-4">
                  {plan.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-start gap-3">
                      <Check className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-foreground">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Nota adicional */}
        <div className="mt-12 text-center">
          <p className="text-muted-foreground">
            Todos los planes incluyen instalación gratis y sin contrato de permanencia
          </p>
        </div>
      </div>
    </section>
  );
}

export default Plans;

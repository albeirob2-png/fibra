import { Button } from "@/components/ui/button";
import { HERO, COMPANY_INFO } from "@/data/content";
import { ArrowRight } from "lucide-react";

interface HeroProps {
  onCtaClick?: () => void;
}

export function Hero({ onCtaClick }: HeroProps) {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background">
      {/* Imagen de fondo */}
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage:
            'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663619836959/jSrDYwLpzzFeHqksKux63d/hero-fiber-optic-KMBStFVmPdWBZfXwL2FoYh.webp)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed',
        }}
      >
        {/* Overlay oscuro para mejorar legibilidad */}
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/80 to-background/40" />
      </div>

      {/* Contenido */}
      <div className="relative z-10 container max-w-5xl mx-auto px-4 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Texto */}
          <div className="space-y-8">
            {/* Etiqueta */}
            <div className="inline-block">
              <span className="text-sm font-semibold text-primary uppercase tracking-wider">
                Tecnología de Última Generación
              </span>
            </div>

            {/* Título principal */}
            <h1 className="text-5xl md:text-6xl font-bold font-bold text-foreground leading-tight">
              {HERO.title}
            </h1>

            {/* Subtítulo */}
            <p className="text-xl text-muted-foreground leading-relaxed max-w-lg">
              {HERO.subtitle}
            </p>

            {/* Descripción */}
            <p className="text-base text-muted-foreground leading-relaxed max-w-lg">
              {HERO.description}
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                size="lg"
                className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 group"
                onClick={onCtaClick}
              >
                {HERO.cta}
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-2 border-primary text-primary hover:bg-primary/5 font-semibold rounded-lg"
              >
                {HERO.ctaSecondary}
              </Button>
            </div>

            {/* Indicadores de confianza */}
            <div className="flex items-center gap-6 pt-8 border-t border-border">
              <div>
                <p className="text-2xl font-bold text-primary">+50K</p>
                <p className="text-sm text-muted-foreground">Clientes Satisfechos</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-primary">99.9%</p>
                <p className="text-sm text-muted-foreground">Disponibilidad</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-primary">24/7</p>
                <p className="text-sm text-muted-foreground">Soporte Técnico</p>
              </div>
            </div>
          </div>

          {/* Imagen decorativa (solo desktop) */}
          <div className="hidden lg:flex justify-center items-center">
            <div className="relative w-full aspect-square max-w-md">
              {/* Elemento decorativo con gradiente */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-full blur-3xl" />
              <div className="relative z-10 w-full h-full flex items-center justify-center">
                <div className="text-6xl">⚡</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Indicador de scroll */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-bounce">
        <svg
          className="w-6 h-6 text-primary"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M19 14l-7 7m0 0l-7-7m7 7V3"
          />
        </svg>
      </div>
    </section>
  );
}

export default Hero;

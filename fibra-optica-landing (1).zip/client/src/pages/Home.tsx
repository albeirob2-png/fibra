import { useRef } from "react";
import Header from "@/components/Header";
import { Hero } from "@/components/sections/Hero";
import { Benefits } from "@/components/sections/Benefits";
import { Plans } from "@/components/sections/Plans";
import { Coverage } from "@/components/sections/Coverage";
import { Testimonials } from "@/components/sections/Testimonials";
import { FAQ } from "@/components/sections/FAQ";
import { ContactForm } from "@/components/sections/ContactForm";
import Footer from "@/components/Footer";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { toast } from "sonner";

export default function Home() {
  const contactFormRef = useRef<HTMLDivElement>(null);

  const handleCtaClick = () => {
    // Scroll suave al formulario de contacto
    contactFormRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleSelectPlan = (planName: string) => {
    toast.info(`Plan ${planName} seleccionado. Completa el formulario para continuar.`);
    handleCtaClick();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <Header onContactClick={handleCtaClick} />

      {/* Hero */}
      <section id="hero">
        <Hero onCtaClick={handleCtaClick} />
      </section>

      {/* Benefits */}
      <section id="benefits">
        <Benefits />
      </section>

      {/* Plans */}
      <section id="plans">
        <Plans onSelectPlan={handleSelectPlan} />
      </section>

      {/* Coverage */}
      <section id="coverage">
        <Coverage />
      </section>

      {/* Testimonials */}
      <section id="testimonials">
        <Testimonials />
      </section>

      {/* FAQ */}
      <section id="faq">
        <FAQ />
      </section>

      {/* Contact Form */}
      <section id="contact" ref={contactFormRef}>
        <ContactForm />
      </section>

      {/* Footer */}
      <Footer />

      {/* WhatsApp Button */}
      <WhatsAppButton />
    </div>
  );
}
